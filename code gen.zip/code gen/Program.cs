﻿using System;
using System.Diagnostics;
using System.Text;
using System.Threading;

namespace code_gen
{
    class Program
    {
        static DateTime date = DateTime.Now;

        static void logo()
        {
            string test = string.Format(@"           __                              __     {0}          |  \                            |  \{0}  _______ | $$   __   ______    ______   _| $$_{0} /       \| $$  /  \ /      \  /      \ |   $$ \{0}|  $$$$$$$| $$_/  $$|  $$$$$$\|  $$$$$$\ \$$$$$${0} \$$    \ | $$   $$ | $$    $$| $$    $$  | $$ __{0} _\$$$$$$\| $$$$$$\ | $$$$$$$$| $$$$$$$$  | $$|  \{0}|       $$| $$  \$$\ \$$     \ \$$     \   \$$  $${0} \$$$$$$$  \$$   \$$  \$$$$$$$  \$$$$$$$    \$$$${0}{0}", Environment.NewLine);
            for (int i = 0; i < test.Length; i++)
            {
                Console.Write(test[i]);
            }
        }

        static void patch()
        {
            Console.Write("Patching...");
            Thread.Sleep(900);

            ProcessStartInfo patched = new ProcessStartInfo();
            patched.Arguments = "-patched";
            patched.CreateNoWindow = true;
            patched.FileName = System.Reflection.Assembly.GetExecutingAssembly().Location;
            Process.Start(patched);
            Environment.Exit(0);
        }

        static void credentials()
        {
            Console.Write("username: ");
            string username = Console.ReadLine();
            Console.Clear();

            logo();

            string password = "";
            Console.Write("password: ");
            ConsoleKeyInfo key;

            try
            {
                do
                {
                    key = Console.ReadKey(true);
                    password += key.KeyChar;
                    if ((key.Key == ConsoleKey.Enter) || (key.Key == ConsoleKey.Backspace))
                    {
                        password = password.Remove(password.Length - 1);
                        Console.Write("\b \b");
                    }
                }
                while (key.Key != ConsoleKey.Enter);
            }
            catch (Exception ex)
            {
                Console.Write(ex.Message);
            }

            Console.Clear();
            login(username, password);
        }

        static void login(string v1, string v2)
        {
            if ((v1 == "admin") && (v2 == "admin"))
            {
                menu(v1);
            }
            else
            {
                Console.Write("failure");
                Environment.Exit(0);
            }
        }

        static void menu(string g1)
        {
            Console.Title = "SKEET ADMIN PANEL | " + g1 + " | " + date;

            logo();

            Console.WriteLine("welcome " + g1);
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("commands: cmds, clear, generate");
            Console.ResetColor();

            listen();
        }

        static void listen()
        {
            string command = Console.ReadLine();
            do_command(command);
        }

        static void do_command(string cmd)
        {
            if (cmd == "cmds")
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("commands: cmds, clear, generate");
                Console.ResetColor();
                listen();
            }
            else if (cmd == "clear")
            {
                Console.Clear();
                logo();
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("commands: cmds, clear, generate");
                Console.ResetColor();
                listen();
            }
            else if (cmd == "generate")
            {
                Console.WriteLine(gencode(48));
                listen();
            }
        }

        public static string gencode(int length)
        {
            Random random = new Random();
            string characters = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
            StringBuilder result = new StringBuilder(length);
            for (int i = 0; i < length; i++)
            {
                result.Append(characters[random.Next(characters.Length)]);
            }
            return result.ToString();
        }

        static void Main(string[] args)
        {        
            Console.Title = "SKEET ADMIN PANEL |  |" + date;

            logo();

            if (args.Length <= 0)
                patch();

            if (args.Length > 0)
            {
                if (args[0].ToString() == "-patched")
                {
                    credentials();
                    Console.ReadKey();
                }
            }
        }
    }
}
